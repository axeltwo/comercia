import { Hammer } from 'lucide-react'
import { useLocation } from 'react-router-dom'
import { NAV_ITEMS } from '../components/layout/nav'
import { PageHeader, EmptyState } from '../components/ui/Feedback'

export default function ComingSoonPage() {
  const { pathname } = useLocation()
  const item = NAV_ITEMS.find((i) => i.to === pathname)
  return (
    <>
      <PageHeader title={item?.label ?? 'Módulo'} />
      <div className="card">
        <EmptyState
          icon={<Hammer size={22} />}
          title="Este módulo se habilita en una próxima etapa"
          description={item?.description ?? 'Todavía no está disponible.'}
        />
      </div>
    </>
  )
}
