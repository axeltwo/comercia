export interface Category {
  id: string
  name: string
  description: string | null
}

export interface Product {
  id: string
  business_id: string
  category_id: string | null
  name: string
  sku: string
  barcode: string | null
  description: string | null
  cost_cents: number
  price_cents: number
  stock_quantity: number
  min_stock: number
  created_at: string
  updated_at: string
}

export type MovementType = 'initial' | 'entry' | 'exit' | 'adjustment' | 'sale' | 'sale_cancel'

export const MOVEMENT_LABELS: Record<MovementType, string> = {
  initial: 'Stock inicial',
  entry: 'Entrada',
  exit: 'Salida',
  adjustment: 'Ajuste',
  sale: 'Venta',
  sale_cancel: 'Venta cancelada',
}

export interface DashboardSummary {
  products_count: number
  low_stock_count: number
  out_of_stock_count: number
  today_sales_count: number
  today_total_cents: number
  month_revenue_cents: number
  month_cost_cents: number
  daily: { date: string; total_cents: number; count: number }[]
  top_products: { product_id: string; name: string; quantity: number; revenue_cents: number }[]
  recent_movements: {
    id: string
    movement_type: MovementType
    quantity_delta: number
    stock_after: number
    reason: string | null
    created_at: string
    product_name: string
  }[]
  low_stock_products: { id: string; name: string; sku: string; stock_quantity: number; min_stock: number }[]
}
