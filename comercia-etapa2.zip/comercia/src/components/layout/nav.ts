import { LayoutDashboard, Package, Tags, ArrowLeftRight, ShoppingCart, Users, Truck, BarChart3, type LucideIcon } from 'lucide-react'

export interface NavItem {
  to: string
  label: string
  icon: LucideIcon
  /** false = módulo todavía no implementado (se muestra la pantalla "Próximamente") */
  ready: boolean
  description?: string
}

export const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, ready: true },
  { to: '/productos', label: 'Productos', icon: Package, ready: true },
  { to: '/categorias', label: 'Categorías', icon: Tags, ready: true,
    description: 'Vas a poder crear y editar categorías y ver qué productos tiene cada una.' },
  { to: '/inventario', label: 'Inventario', icon: ArrowLeftRight, ready: true,
    description: 'Registro de entradas, salidas y ajustes de stock con su historial completo.' },
  { to: '/ventas', label: 'Ventas', icon: ShoppingCart, ready: false,
    description: 'Registro de ventas con varios productos, descuentos y método de pago, con descuento de stock automático.' },
  { to: '/clientes', label: 'Clientes', icon: Users, ready: false,
    description: 'Ficha de clientes con su historial de compras.' },
  { to: '/proveedores', label: 'Proveedores', icon: Truck, ready: false,
    description: 'Proveedores asociados a tus productos y base para registrar compras de mercadería.' },
  { to: '/reportes', label: 'Reportes', icon: BarChart3, ready: false,
    description: 'Ventas por período, productos más vendidos, costos y ganancia bruta, con exportación a CSV.' },
]
