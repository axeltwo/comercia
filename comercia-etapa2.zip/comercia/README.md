# Comercia · Gestión de stock y ventas

Sistema web para comercios de Argentina (perfumerías, ropa, accesorios, etc.).
React + TypeScript + Vite + Tailwind CSS · Supabase (PostgreSQL + Auth) · Vercel.

## Estado: Etapa 2

| Módulo | Estado |
|---|---|
| Autenticación (email y contraseña) + alta del negocio | ✅ Funcional |
| Aislamiento de datos por negocio (RLS) | ✅ Funcional y probado |
| Dashboard | ✅ Funcional (las métricas de ventas dependen del módulo Ventas) |
| Productos (crear, editar, eliminar, buscar, filtrar) | ✅ Funcional |
| Categorías (crear, editar, eliminar, cantidad de productos) | ✅ Funcional (etapa 2) |
| Inventario (entradas, salidas, ajustes con motivo, historial con filtros y alertas de stock mínimo) | ✅ Funcional (etapa 2) |
| Ventas, Clientes, Proveedores, Reportes | ⏳ Base de datos y funciones ya listas · pantallas en próximas etapas |

> Las **funciones SQL de ventas, cancelaciones y movimientos de stock ya existen y están probadas**
> (`supabase/migrations/0003_functions.sql`). Lo que falta es construir sus pantallas.

---

## 1. Qué necesitás configurar (una sola vez)

### A. Crear el proyecto en Supabase
1. Entrá a <https://supabase.com> → **New project**. Elegí una región cercana (por ej. *South America (São Paulo)*) y guardá la contraseña de la base.
2. Cuando termine de crearse, andá a **SQL Editor** → **New query**.
3. Pegá y ejecutá **en este orden**, un archivo por vez (botón *Run*):
   1. `supabase/migrations/0001_schema.sql`
   2. `supabase/migrations/0002_rls.sql`
   3. `supabase/migrations/0003_functions.sql`
   4. `supabase/migrations/0004_inventory_view.sql` *(nuevo en la etapa 2; si ya hiciste los 3 primeros, ejecutá solo este)*

   Cada uno debe terminar con *Success*. Si uno falla, **no sigas**: copiame el error.
4. Verificá en **Table Editor** que aparezcan las tablas (`businesses`, `products`, `sales`, …) y que todas muestren el candado de **RLS enabled**.

### B. Configurar la autenticación
En **Authentication → Providers → Email**:
- Para **probar rápido en tu computadora**, podés desactivar *Confirm email* (así entrás sin confirmar el correo).
- Para **producción**, dejalo activado.

En **Authentication → URL Configuration**:
- *Site URL*: `http://localhost:5173` (cuando publiques, la cambiás por la URL de Vercel).
- *Redirect URLs*: agregá `http://localhost:5173/**` y, más adelante, `https://TU-APP.vercel.app/**`.

### C. Copiar las claves al proyecto
1. En Supabase: **Project Settings → API** (o el botón **Connect**).
2. Copiá la **Project URL** y la clave **anon / publishable**.
3. En la raíz del proyecto, copiá `.env.example` como **`.env.local`** y completá:
   ```
   VITE_SUPABASE_URL=https://xxxxxxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...
   ```
> 🔒 **Nunca** uses la clave `service_role` en este proyecto ni la subas a GitHub. La clave `anon` es pública *por diseño*: la seguridad la dan las políticas RLS de la base. `.env.local` ya está en `.gitignore`.

## 2. Ejecutar localmente
```bash
npm install
npm run dev        # abre http://localhost:5173
npm run build      # verifica tipos y compila para producción
```
Requiere Node.js 18 o superior.

## 3. Cómo probar la Etapa 1
1. **Registrate** con un email y una contraseña (mínimo 8 caracteres). Si dejaste *Confirm email* activado, confirmá el correo primero.
2. Ingresá el **nombre de tu negocio**. Esto crea el negocio y te asigna como dueño.
3. En **Productos → Nuevo producto**: cargá nombre, SKU, costo, precio y stock inicial. Verificá que el margen se calcule en pantalla.
4. Probá **editar**, **buscar** (nombre, SKU o código de barras), **filtrar** por categoría/disponibilidad y **eliminar**.
5. Volvé al **Dashboard**: debe mostrar el producto, el movimiento "Stock inicial" y, si el stock queda en o bajo el mínimo, la alerta.
6. **Prueba de aislamiento**: cerrá sesión, registrá un segundo usuario con otro email y comprobá que **no ve nada** del primero.
7. En **Table Editor → stock_movements** vas a ver cada movimiento registrado. En **SQL Editor** podés correr `select * from stock_audit;`: la columna `consistent` debe ser siempre `true`.

### Probar la Etapa 2
1. **Categorías → Nueva categoría**: creá una, editala y asignala desde el formulario de un producto. Al eliminarla, sus productos quedan "sin categoría" (no se borran).
2. **Inventario → Registrar movimiento**: probá una *Entrada*, una *Salida* y un *Ajuste* (este exige motivo). Si intentás sacar más de lo que hay, el sistema lo bloquea y muestra el stock resultante antes de confirmar.
3. Revisá el **historial**: filtrá por producto/SKU, tipo y fechas, y usá "Cargar más".
4. Si un producto llega al stock mínimo aparece un aviso con el botón **Reponer**.
5. En SQL Editor: `select * from stock_audit;` debe seguir mostrando `consistent = true` en todas las filas.

## 4. Publicar (GitHub + Vercel)
```bash
git init && git add . && git commit -m "Etapa 1: base del sistema"
# creá un repositorio vacío en GitHub y seguí sus instrucciones para el "git remote add" y "git push"
```
En <https://vercel.com> → **Add New → Project** → importá el repositorio. Vercel detecta Vite solo.
Antes de desplegar, en **Settings → Environment Variables** cargá `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY`.
Después actualizá *Site URL* y *Redirect URLs* en Supabase con la URL que te dé Vercel. `vercel.json` ya resuelve las rutas de la SPA.

---

## 5. Arquitectura y decisiones

```
Navegador (React) ──HTTPS──▶ Supabase
   │                          ├─ Auth (sesiones/JWT)
   │  clave anon (pública)    ├─ PostgREST: lectura/escritura simple, filtrada por RLS
   └──────────────────────────└─ Funciones SQL (RPC): operaciones críticas y atómicas
```

**No hay servidor propio**: lo sensible vive en PostgreSQL, que es quien garantiza la consistencia.

| Decisión | Motivo |
|---|---|
| **Dinero en centavos (`bigint`)** | Evita errores de redondeo de decimales/floats. Solo se formatea para mostrar. |
| **Stock = caché + movimientos** | `products.stock_quantity` se actualiza **solo** desde funciones; cada cambio deja una fila inmutable en `stock_movements`. La vista `stock_audit` compara ambos. |
| **Los clientes no pueden escribir stock, ventas ni movimientos** | `REVOKE` + permisos por columna: aunque alguien manipule el frontend, la base lo rechaza. |
| **Ventas por función `create_sale`** | Una transacción: bloquea productos (`FOR UPDATE`), valida stock, copia precio/costo históricos, descuenta stock y registra movimientos. Si algo falla, no se guarda nada. |
| **Idempotencia (`client_request_id`)** | Reintentar o hacer doble clic en "Confirmar venta" no duplica la venta ni el descuento. |
| **Precio y costo salen de la base** | El cliente solo manda producto y cantidad: no puede falsear importes. |
| **Cancelación (`cancel_sale`)** | Marca la venta, exige motivo y devuelve el stock con movimientos `sale_cancel`. No borra nada. |
| **"Eliminar" producto = archivar (`deleted_at`)** | Las ventas y movimientos pasados siguen mostrando el producto. |
| **Multi-negocio desde el día 1** | Toda tabla lleva `business_id`; claves foráneas compuestas impiden mezclar datos de negocios distintos. |
| **Ventas ≠ caja ≠ ganancia** | "Ingresos" = ventas confirmadas (no canceladas). "Ganancia bruta estimada" = ingresos − costo de lo vendido, **antes** de impuestos, comisiones y gastos. El registro de caja real queda para una etapa futura. |

### Estructura de carpetas
```
supabase/
  migrations/   0001 esquema · 0002 seguridad (RLS) · 0003 funciones · 0004 vista de historial
  tests/        pruebas SQL (se ejecutan en un PostgreSQL local; ver abajo)
src/
  lib/          dinero, fechas, errores en español, cliente Supabase, tipos
  context/      sesión y negocio activo
  components/   ui/ (botones, modal, toasts…) · layout/ (sidebar, navegación)
  features/     products/ (API, validación, formulario) · dashboard/
  pages/        una pantalla por ruta
```

## 6. Límites conocidos de esta etapa
- Un usuario = un negocio (la base ya admite varios; falta el selector en pantalla).
- Solo existe el rol *owner*; los roles `admin`/`staff` están en el esquema pero sin permisos diferenciados todavía.
- La lista de productos carga hasta 2.000 y filtra en el navegador (suficiente para comercios chicos; luego se pagina).
- En Productos solo se define el stock inicial; después se modifica únicamente desde Inventario (queda registrado).
- Requiere PostgreSQL 15+ (los proyectos nuevos de Supabase ya lo usan).
- Sin facturación electrónica ARCA ni medios de pago, según lo acordado.

## 7. Pruebas de la base de datos (opcional)
`supabase/tests/` tiene un guion que simula dos negocios y comprueba aislamiento, stock negativo, idempotencia,
cancelaciones y auditoría. Se ejecuta contra un PostgreSQL local (no contra Supabase):
`00_stub_supabase.sql` crea los roles/`auth.uid()` mínimos, luego las 4 migraciones y por último `01_reglas_de_negocio.sql`.
